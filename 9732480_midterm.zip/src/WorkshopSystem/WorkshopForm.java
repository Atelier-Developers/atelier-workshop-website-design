package WorkshopSystem;

import WorkshopSystem.FormService.Form;

/*
    dar in form, form applicant WorkshopAttenderFormApplicant ya GroupFormApplicant hast va Answer ham FilledAnswer va FormFiller ham
    WorkshopGraderFormFiller
 */

public class WorkshopForm extends Form {

}
