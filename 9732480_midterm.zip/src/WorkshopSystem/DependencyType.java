package WorkshopSystem;

public enum DependencyType {
    PREREQUISITE,
    HAMNIAZ
}
