package WorkshopSystem;

import WorkshopSystem.FormService.FormApplicant;

public class WorkshopAttenderFormApplicant extends FormApplicant {
}
