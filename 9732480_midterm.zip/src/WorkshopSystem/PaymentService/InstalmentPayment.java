package WorkshopSystem.PaymentService;

import java.util.Calendar;

public class InstalmentPayment implements Payment {
    private double value;
    private Calendar dueDate;
}
