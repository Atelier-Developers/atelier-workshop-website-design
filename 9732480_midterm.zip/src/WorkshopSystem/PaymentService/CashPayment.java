package WorkshopSystem.PaymentService;

import java.util.Calendar;

public class CashPayment implements Payment {
    private double value;
    private Calendar paymentDate;
}
