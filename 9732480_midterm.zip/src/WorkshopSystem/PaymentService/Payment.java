package WorkshopSystem.PaymentService;

public interface Payment {
}
