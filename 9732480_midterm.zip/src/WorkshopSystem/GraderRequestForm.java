package WorkshopSystem;

import WorkshopSystem.FormService.Form;
import WorkshopSystem.RequestService.RequestData;

/*
    dar in form, form applicant GraderFormApplicant hast va Answer ham Answer
 */

public class GraderRequestForm extends Form implements RequestData {
}
