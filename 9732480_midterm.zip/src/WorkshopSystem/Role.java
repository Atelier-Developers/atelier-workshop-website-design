package WorkshopSystem;

public interface Role {
}
