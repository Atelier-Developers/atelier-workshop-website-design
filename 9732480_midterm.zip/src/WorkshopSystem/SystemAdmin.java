package WorkshopSystem;

public class SystemAdmin implements Role {
}
