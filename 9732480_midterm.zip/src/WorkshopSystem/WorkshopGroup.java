package WorkshopSystem;

import java.util.List;

public class WorkshopGroup {
    private String name;
    private List<WorkshopGraderInfo> graderInfos;
    private List<WorkshopAttenderInfo> atendeeInfos;
    private List<GroupFormApplicant> groupFormApplicants;
}
