package WorkshopSystem;

import WorkshopSystem.RequestService.Requester;

import java.util.List;

public class Grader extends Requester implements Role {
    private List<WorkshopGraderInfo> workshopGraderInfos;
    private List<GraderFormApplicant> graderFormApplicants;
}
