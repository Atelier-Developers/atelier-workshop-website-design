package WorkshopSystem;

import WorkshopSystem.FormService.FormApplicant;

public class GraderFormApplicant extends FormApplicant {
}
