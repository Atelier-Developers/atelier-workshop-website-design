package WorkshopSystem;

import WorkshopSystem.FormService.FormApplicant;

public class WorkshopGraderFormApplicant extends FormApplicant {

}
