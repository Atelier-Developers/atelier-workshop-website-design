package WorkshopSystem;

import java.util.List;

public class User {
    private String name;
    private String userName;
    private String password;
    private String address;
    private List<Role> roles;
}
