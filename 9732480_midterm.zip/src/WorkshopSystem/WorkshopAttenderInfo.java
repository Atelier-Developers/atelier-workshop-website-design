package WorkshopSystem;

import java.util.List;

public class WorkshopAttenderInfo {
    private List<WorkshopAttenderFormApplicant> workshopAttenderFormApplicants;
}
