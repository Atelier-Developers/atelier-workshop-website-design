package WorkshopSystem;


import java.util.List;

public class WorkshopGraderInfo {
    private List<WorkshopGraderFormFiller> formFillers;
    private List<WorkshopGraderFormApplicant> workshopGraderFormApplicants;
}
