package WorkshopSystem;

import java.util.List;

public class WorkshopManager implements Role {
    private List<Workshop> workshops;
    private List<WorkshopManagerFormFiller> formFillerList;
}
