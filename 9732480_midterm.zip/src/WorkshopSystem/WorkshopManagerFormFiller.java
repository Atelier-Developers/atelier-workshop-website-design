package WorkshopSystem;

import WorkshopSystem.FormService.FormFiller;

public class WorkshopManagerFormFiller extends FormFiller {
}
