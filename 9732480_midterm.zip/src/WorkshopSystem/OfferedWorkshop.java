package WorkshopSystem;

import java.util.List;

public class OfferedWorkshop {
    private String name;
    private List<Workshop> workshops;
    private List<OfferedWorkshopRelationDetail> offeredWorkshopRelationDetails;
}
