package WorkshopSystem;

public class OfferedWorkshopRelationDetail {
    private DependencyType dependencyType;
}
