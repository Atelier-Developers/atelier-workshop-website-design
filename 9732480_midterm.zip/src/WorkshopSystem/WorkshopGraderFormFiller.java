package WorkshopSystem;

import WorkshopSystem.FormService.FormFiller;

public class WorkshopGraderFormFiller extends FormFiller {
}
