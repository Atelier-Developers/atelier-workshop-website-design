package WorkshopSystem.RequestService;

import java.util.List;

public class Request {
    private List<RequestData> requestData;
    private boolean isAccepted;
}
