package WorkshopSystem.RequestService;

import java.util.List;

public abstract class Requestable {
    private List<Request> requests;
}
