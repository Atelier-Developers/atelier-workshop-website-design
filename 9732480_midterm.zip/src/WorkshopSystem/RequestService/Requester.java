package WorkshopSystem.RequestService;

import java.util.List;

public abstract class Requester {
    protected List<Request> requests;
}
