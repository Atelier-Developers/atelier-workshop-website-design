package WorkshopSystem.RequestService;

import WorkshopSystem.FormService.FormApplicant;

public class AttenderFormApplicant extends FormApplicant {
}
