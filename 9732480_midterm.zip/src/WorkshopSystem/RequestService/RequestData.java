package WorkshopSystem.RequestService;

public interface RequestData {
}
