package WorkshopSystem;

import WorkshopSystem.RequestService.AttenderFormApplicant;
import WorkshopSystem.RequestService.Requester;

import java.util.List;

public class Attender extends Requester implements Role{
    private List<WorkshopAttenderInfo> workshopAttenderInfos;
    private List<AttenderFormApplicant> attenderFormApplicants;
}
