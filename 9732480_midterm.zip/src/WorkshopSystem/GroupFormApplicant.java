package WorkshopSystem;

import WorkshopSystem.FormService.FormApplicant;

public class GroupFormApplicant extends FormApplicant {
}
