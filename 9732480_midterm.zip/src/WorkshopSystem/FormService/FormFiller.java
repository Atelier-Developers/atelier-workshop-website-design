package WorkshopSystem.FormService;

import java.util.List;

public abstract class FormFiller {
    protected List<FilledAnswer> answers;
}
