package WorkshopSystem.FormService;

public enum AnswerType {
    CHOICE, TEXT
}
