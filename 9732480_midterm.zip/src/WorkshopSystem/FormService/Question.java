package WorkshopSystem.FormService;

import java.util.List;

public class Question {
    private String text;
    private List<Answerable> answerables;
    private List<Answer> answers;
}
