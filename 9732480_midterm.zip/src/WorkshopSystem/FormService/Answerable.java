package WorkshopSystem.FormService;

import java.util.List;

public class Answerable {
    private String text;
    private AnswerType answerType;
}
