package WorkshopSystem.FormService;

import java.util.List;

public abstract class Form {
    protected String name;
    protected List<Question> questions;
}
