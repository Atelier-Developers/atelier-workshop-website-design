package WorkshopSystem.FormService;

public class FilledAnswer extends Answer {
}
