package WorkshopSystem.FormService;

import java.util.List;

public class Answer {
    private AnswerData answerData;
}
