package WorkshopSystem.FormService;

import java.util.List;

public abstract class FormApplicant {
    protected List<Answer> answers;
}
