package WorkshopSystem.FormService;

public interface AnswerData {
}
