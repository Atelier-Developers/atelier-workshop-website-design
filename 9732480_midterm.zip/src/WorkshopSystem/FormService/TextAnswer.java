package WorkshopSystem.FormService;

public class TextAnswer implements AnswerData{
    private String text;
}
