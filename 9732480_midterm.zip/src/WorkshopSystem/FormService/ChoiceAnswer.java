package WorkshopSystem.FormService;

public class ChoiceAnswer implements AnswerData{
    private int choice;
}
