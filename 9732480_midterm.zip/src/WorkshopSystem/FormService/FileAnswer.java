package WorkshopSystem.FormService;

import java.io.File;

public class FileAnswer implements AnswerData{
    private File file;
}
